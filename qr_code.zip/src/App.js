import { useEffect } from 'react';
import { apiRedirectURL } from "./services/redirectURL"

function App() {

  useEffect(() => {
    const fetchURL = async () => {
      const response = await apiRedirectURL();

      if (response?.status === 200) {
        window.location = response.data.RedirectURL
      }
    };
    fetchURL();
  }, []);

  return (
    <></>
  );
}

export default App;
